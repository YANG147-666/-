const path = require('path'); // 新增这一行
const express = require('express');
const axios = require('axios');
const app = express();
const http = require('http').createServer(app);
app.get('/MP_verify_qWWeAQM3dPUfFpwd.txt', (req, res) => {
    // 自动找到当前文件夹下的该文件
    const filePath = path.join(__dirname, 'MP_verify_qWWeAQM3dPUfFpwd.txt');
    res.sendFile(filePath); 
});
const io = require('socket.io')(http);


// ================= 配置区 (请在这里修改) =================

// 1. 微信测试号配置
const WX_APP_ID = 'wx83c0e40556e9c9b5'; 
const WX_APP_SECRET = 'afa4c8304e6e6e3f8788b328ebd2f38a'; 

// 2. 你的云托管域名 (必须移到最上面！)
// 注意：如果以后换了环境，记得来这里改
const DOMAIN = process.env.DOMAIN || 'https://express-fcke-204673-6-1330326648.sh.run.tcloudbase.com'; 

// 3. 端口配置
const PORT = process.env.PORT || 80; 

// ======================================================

const WIN_SCORE = 100;
let gameState = 'waiting'; 
let players = {}; 

// --- 核心 Socket 逻辑 ---

io.on('connection', (socket) => {
    // 玩家加入
    socket.on('join_game', (userInfo) => {
        if (!players[socket.id]) {
            players[socket.id] = {
                id: socket.id,
                name: userInfo.nickname,
                avatar: userInfo.headimgurl,
                score: 0,
                color: `hsl(${Math.random() * 360}, 70%, 60%)`
            };
            io.emit('update_players', players);
            socket.emit('game_state_change', gameState);
        }
    });

    // 管理员开始游戏
    socket.on('admin_start_game', () => {
        if (gameState === 'racing') return;
        Object.keys(players).forEach(id => players[id].score = 0);
        io.emit('update_players', players);
        
        gameState = 'countdown';
        io.emit('game_state_change', 'countdown');
        
        let count = 3;
        const timer = setInterval(() => {
            io.emit('countdown_tick', count);
            count--;
            if (count < 0) {
                clearInterval(timer);
                gameState = 'racing';
                io.emit('game_state_change', 'racing');
            }
        }, 1000);
    });

    // 重置游戏
    socket.on('admin_reset_game', () => {
        gameState = 'waiting';
        Object.keys(players).forEach(id => players[id].score = 0);
        io.emit('update_players', players);
        io.emit('game_state_change', 'waiting');
    });

    // 摇一摇监听
    socket.on('shake', () => {
        if (gameState !== 'racing') return;
        const player = players[socket.id];
        if (player) {
            player.score += 4 + Math.random() * 2; // 摇动幅度
            if (player.score >= WIN_SCORE) {
                player.score = WIN_SCORE;
                gameState = 'finished';
                io.emit('game_over', player);
            }
            io.emit('update_players', players);
        }
    });

    socket.on('disconnect', () => {
        if (players[socket.id]) {
            delete players[socket.id];
            io.emit('update_players', players);
        }
    });
});

// --- 路由：微信授权入口 ---
app.get('/mobile', (req, res) => {
    const callbackUrl = encodeURIComponent(`${DOMAIN}/wechat/callback`);
    const url = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${WX_APP_ID}&redirect_uri=${callbackUrl}&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect`;
    res.redirect(url);
});

// --- 路由：微信回调 ---
app.get('/wechat/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.send('用户拒绝授权');

    try {
        // 1. 获取 token
        const tokenResp = await axios.get(`https://api.weixin.qq.com/sns/oauth2/access_token?appid=${WX_APP_ID}&secret=${WX_APP_SECRET}&code=${code}&grant_type=authorization_code`);
        
        if (tokenResp.data.errcode) {
            return res.send('微信授权失败: ' + tokenResp.data.errmsg);
        }

        const { access_token, openid } = tokenResp.data;

        // 2. 获取用户信息
        const userResp = await axios.get(`https://api.weixin.qq.com/sns/userinfo?access_token=${access_token}&openid=${openid}&lang=zh_CN`);
        const userInfo = userResp.data; 

        res.send(renderMobilePage(userInfo));

    } catch (error) {
        console.error(error);
        res.send('登录出错，请检查后台日志');
    }
});

// --- 大屏幕页面 ---
app.get('/', (req, res) => {
    // 渲染二维码，指向 /mobile 路由
    const mobileUrl = `${DOMAIN}/mobile`;

    res.send(`
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <title>年会大屏</title>
        <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
        <style>
            body { background: #b721ff; color: white; display: flex; flex-direction: column; height: 100vh; margin: 0; font-family: sans-serif; overflow: hidden; }
            
            /* 二维码悬浮窗 */
            #qr-box { 
                position: absolute; top: 20px; right: 20px; 
                background: white; padding: 15px; border-radius: 10px; 
                color: black; text-align: center; z-index: 99; 
                box-shadow: 0 0 20px rgba(0,0,0,0.5); 
            }
            #qr-box h3 { margin: 10px 0 0 0; }
            
            /* 跑道区域 */
            .track-container { padding: 20px; flex: 1; border-left: 2px solid white; margin-top: 20px; position: relative; }
            .finish-line { position: absolute; right: 50px; top: 0; bottom: 0; width: 4px; background: red; z-index: 0; }
            
            .lane { position: relative; height: 60px; margin-bottom: 20px; border-bottom: 1px dashed rgba(255,255,255,0.3); }
            
            .avatar-box { 
                position: absolute; transition: left 0.3s linear; top: -10px; 
                text-align: center; width: 60px; z-index: 1;
            }
            .avatar-img { 
                width: 50px; height: 50px; border-radius: 50%; 
                border: 3px solid gold; background: white; 
                box-shadow: 0 2px 5px rgba(0,0,0,0.5);
            }
            .name { 
                display: block; font-size: 12px; background: rgba(0,0,0,0.6); 
                padding: 2px 4px; border-radius: 4px; white-space: nowrap; 
                overflow: hidden; text-overflow: ellipsis; 
            }

            /* 倒计时遮罩 */
            #overlay {
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background: rgba(0,0,0,0.8); z-index: 200;
                display: none; justify-content: center; align-items: center;
                font-size: 10em; font-weight: bold; color: gold;
            }

            /* 控制按钮 */
            #controls { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); z-index: 100; }
            button { padding: 10px 25px; font-size: 1.2em; cursor: pointer; border: none; border-radius: 5px; margin: 0 10px; }
            .btn-start { background: gold; color: #d00; font-weight: bold; }
        </style>
    </head>
    <body>
        <div id="qr-box">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(mobileUrl)}" />
            <h3>微信扫码加入</h3>
        </div>
        
        <div id="overlay"></div>

        <div class="track-container" id="tracks">
            <div class="finish-line"></div>
        </div>
        
        <div id="controls">
            <button class="btn-start" onclick="socket.emit('admin_start_game')">🏁 开始比赛</button>
            <button onclick="socket.emit('admin_reset_game')">🔄 重置</button>
        </div>

        <script src="/socket.io/socket.io.js"></script>
        <script>
            const socket = io();
            const tracksDiv = document.getElementById('tracks');
            const overlay = document.getElementById('overlay');
            
            // 更新玩家列表
            socket.on('update_players', (players) => {
                tracksDiv.innerHTML = '<div class="finish-line"></div>'; 
                Object.values(players).forEach(p => {
                    const lane = document.createElement('div');
                    lane.className = 'lane';
                    // 留出终点线的一点距离 (92%)
                    const left = Math.min(p.score, 92) + '%';
                    lane.innerHTML = \`
                        <div class="avatar-box" style="left: \${left}">
                            <img src="\${p.avatar}" class="avatar-img">
                            <span class="name">\${p.name}</span>
                        </div>
                    \`;
                    tracksDiv.appendChild(lane);
                });
            });

            // 倒计时显示
            socket.on('game_state_change', (state) => {
                if (state === 'countdown') {
                    overlay.style.display = 'flex';
                    overlay.innerText = '准备...';
                } else if (state === 'racing') {
                    overlay.style.display = 'none';
                } else {
                    overlay.style.display = 'none';
                }
            });

            socket.on('countdown_tick', (count) => {
                overlay.innerText = count > 0 ? count : 'GO!';
            });

            // 游戏结束
            socket.on('game_over', (winner) => {
                // 简单的胜者弹窗 + 礼花
                confetti({ particleCount: 200, spread: 70, origin: { y: 0.6 } });
                setTimeout(() => {
                    alert('🎉 获胜者: ' + winner.name + ' 🎉');
                }, 500);
            });
        </script>
    </body>
    </html>
    `);
});


// --- 渲染手机端页面的函数 ---
function renderMobilePage(userInfo) {
    const userJson = JSON.stringify({
        nickname: userInfo.nickname,
        headimgurl: userInfo.headimgurl,
        openid: userInfo.openid
    });

    return `
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <title>年会摇一摇</title>
        <style>
            body { background: #e60012; color: white; text-align: center; font-family: sans-serif; padding-top: 50px; overflow: hidden; touch-action: none; }
            #avatar { width: 80px; height: 80px; border-radius: 50%; border: 3px solid gold; margin-bottom: 10px; }
            #status { font-size: 2em; font-weight: bold; margin: 20px 0; }
            .btn { background: gold; color: #d00; border: none; padding: 15px 40px; font-size: 1.2em; border-radius: 30px; font-weight: bold; cursor: pointer; }
            .hidden { display: none; }
            #shake-icon { font-size: 5em; transition: transform 0.1s; display: inline-block; }
        </style>
    </head>
    <body>
        <img id="avatar" src="${userInfo.headimgurl}">
        <h2>你好，${userInfo.nickname}</h2>
        
        <div id="setup-step">
            <button class="btn" onclick="joinGame()">🚀 进入赛场</button>
            <p style="margin-top:20px; font-size:0.9em; opacity:0.8">请务必点击允许【动作与方向】权限</p>
        </div>

        <div id="game-step" class="hidden">
            <div id="status">等待开始...</div>
            <div id="shake-icon">📱</div>
            <p>握紧手机，听从大屏指挥！</p>
        </div>

        <script src="/socket.io/socket.io.js"></script>
        <script>
            const socket = io();
            const user = ${userJson}; 
            const shakeIcon = document.getElementById('shake-icon');
            
            async function joinGame() {
                // 1. 请求传感器权限 (iOS 13+ 必需)
                if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') {
                    try {
                        const res = await DeviceMotionEvent.requestPermission();
                        if (res !== 'granted') return alert('必须授权传感器才能玩游戏哦！');
                    } catch (e) { return alert(e); }
                }

                // 2. 发送加入请求
                socket.emit('join_game', user);
                
                document.getElementById('setup-step').classList.add('hidden');
                document.getElementById('game-step').classList.remove('hidden');
                startSensor();
            }

            socket.on('game_state_change', (state) => {
                const s = document.getElementById('status');
                if (state === 'waiting') s.innerText = '等待中...';
                if (state === 'countdown') s.innerText = '准备!';
                if (state === 'racing') {
                    s.innerText = '疯狂摇动!';
                    if(navigator.vibrate) navigator.vibrate(200);
                }
                if (state === 'finished') s.innerText = '比赛结束';
            });

            // 传感器逻辑
            let lastUpdate = 0;
            function startSensor() {
                window.addEventListener('devicemotion', (e) => {
                    const now = Date.now();
                    if (now - lastUpdate > 100) {
                        let acc = e.acceleration;
                        // 安卓兼容性处理
                        if (!acc || acc.x === null) acc = e.accelerationIncludingGravity;
                        
                        const total = Math.abs(acc.x) + Math.abs(acc.y) + Math.abs(acc.z);
                        // 阈值判断
                        const threshold = (e.acceleration && e.acceleration.x) ? 15 : 40;
                        
                        if (total > threshold) {
                            socket.emit('shake');
                            lastUpdate = now;
                            
                            // 视觉反馈
                            shakeIcon.style.transform = 'rotate(' + (Math.random()*40 - 20) + 'deg) scale(1.2)';
                            setTimeout(() => shakeIcon.style.transform = 'scale(1)', 100);
                            
                            if(navigator.vibrate) navigator.vibrate(20);
                        }
                    }
                });
            }
        </script>
    </body>
    </html>
    `;
}

// ================= 启动服务 =================
http.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Current Domain: ${DOMAIN}`);
});